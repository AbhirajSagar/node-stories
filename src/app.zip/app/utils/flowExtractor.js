export default function extractFlowData(flow, version)
{
    if(version === 0.1)
        return extractFlowDataV01(flow);
}

function extractFlowDataV01(flow)
{
    return {
        slides: flow.slides,
        appearance: flow.appearance,
        name: flow.name,
        description: flow.description,
        timing: flow.timing,
    };
}