"use client";

import NormalSlideNode from "../components/customNodes/NormalSlideNode";
import TextImageSlideNode from "../components/customNodes/TextImageSlideNode";
import TextVideoSlideNode from "../components/customNodes/TextVideoSlideNode";

import { useState, useCallback, useEffect } from "react";
import { ReactFlow, applyNodeChanges, applyEdgeChanges, addEdge, Background, BackgroundVariant, ReactFlowProvider } from "@xyflow/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFloppyDisk, faPlayCircle, faGear } from "@fortawesome/free-solid-svg-icons";
import { useRouter } from "next/navigation";

import { ContextMenu, PaneContextMenu, EdgeContextMenu } from "../components/EditorMenu";
import extractFlowData from "../utils/flowExtractor";
import { Settings } from "../components/StorySettings";
import "@xyflow/react/dist/style.css";


const nodeTypes = 
{
    normal: NormalSlideNode,
    image: TextImageSlideNode,
    video: TextVideoSlideNode,
};

const flowKey = "savedFlowData";

export default function Page()
{

    return (
        <ReactFlowProvider>
            <Editor />
        </ReactFlowProvider>
    );
}

function Editor()
{
    const [nodes, setNodes] = useState([]);
    const [edges, setEdges] = useState([]);
    const [menuPos, setMenuPos] = useState({ x: 0, y: 0 });
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [menuContent, setMenuContent] = useState(<PaneContextMenu />);
    const [rfInstance, setReactFlowInstance] = useState(null);
    const [isPreviewVisible, setIsPreviewVisible] = useState(false);
    const [appearance, setAppearance] = useState();
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [timing, setTiming] = useState({});
    const router = useRouter();

    const onNodesChange = useCallback((c) => setNodes((n) => applyNodeChanges(c, n)), []);
    const onEdgesChange = useCallback((c) => setEdges((e) => applyEdgeChanges(c, e)), []);
    const onConnect = useCallback((p) => { setEdges((e) => addEdge(p, e)) }, []);
    const onSave = useCallback(handleSave, [rfInstance]);

    useEffect(() => { tryLoadFlow(); }, []);

    function tryLoadFlow()
    {
        const storedJsonData = sessionStorage.getItem('storyData');
        if(!storedJsonData) return;

        const data = JSON.parse(storedJsonData);
        const {slides, appearance, name, description, timing}  = extractFlowData(data, data?.version || 0.1);
        setAppearance(appearance);
        setName(name);
        setDescription(description);
        setTiming(timing);
        
        console.log(slides);
        for(const slide of slides)
        {
            addNode(slide.type, {x: 0, y: 0}, slide.id);
        }
    }

    function handleSave()
    {
        if(!rfInstance) return;

        const flow = rfInstance.toObject();
        const data = localStorage.setItem(flowKey, JSON.stringify(flow));

        console.log(data);
    }

    function handleContextMenu(menu, event) 
    {
        event.preventDefault();
        setMenuPos({ x: event.clientX, y: event.clientY });
        setMenuContent(menu);
        setIsMenuOpen(true);
    }

    function addNode(nodeType, position, id = null) 
    {
        const randomId = id || crypto.randomUUID();
        const newNode = 
        {
            id: randomId,
            type: nodeType,
            data: 
            {
                text: "",
                choices: [],
            },
            position: position,
        };

        setNodes((prev) => [...prev, newNode]);
        setIsMenuOpen(false);
    }

    function deleteEdge(id) 
    {
        setEdges(edges.filter((e) => e.id !== id));
        setIsMenuOpen(false);
    }   

    function getStoryJsonObj()
    {
        const slidesArray = [];
        for(let node of nodes)
        {
            const {id, type, data} = node;
            slidesArray.push({id, type, data});
        }

        const storyObj = 
        {
            version: 0.1,
            name,
            description,
            appearance,
            timing,
            slides: slidesArray,
        };

        return storyObj;
    }

    function playStory()
    {
        const data = getStoryJsonObj();
        sessionStorage.setItem('storyData', JSON.stringify(data));
        router.push('/player');
    }

    function validateConnection(connection)
    {
        const existing = edges.find((e) => e.source === connection.source && e.sourceHandle === connection.sourceHandle);
        return !existing;
    }

    return (
        <div style={{ width: "100vw", height: "100vh" }}>
            <ReactFlow
                nodes={nodes}
                edges={edges}
                nodeTypes={nodeTypes}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                onInit={setReactFlowInstance}
                onPaneContextMenu={(e) => handleContextMenu(<PaneContextMenu addNode={addNode} />, e)}
                onEdgeContextMenu={(e, edge) => handleContextMenu(<EdgeContextMenu edge={edge} deleteEdge={deleteEdge} />, e)}
                autoPanOnNodeFocus={true}
                zoomOnDoubleClick={false}
                onFocus={() => setIsMenuOpen(false)}
                isValidConnection={validateConnection}
                fitView
            >
                <Toolbar isPreviewVisible={isPreviewVisible} setIsPreviewVisible={setIsPreviewVisible} onSave={onSave}  playStory={playStory}/>
                {
                    isPreviewVisible && (
                    <Settings 
                        setIsPreviewVisible={setIsPreviewVisible}
                        appearance={appearance}
                        setAppearance={setAppearance}
                        name={name}
                        description={description}
                        setName={setName}
                        setDescription={setDescription}
                        timing={timing}
                        setTiming={setTiming}
                    />)
                }
                <Background variant={BackgroundVariant.Lines} bgColor="#222B3Cff" color="#273041" />
            </ReactFlow>
            {isMenuOpen && <ContextMenu x={menuPos.x} y={menuPos.y} menuContent={menuContent}/>}
        </div>
    );
}

function Toolbar({ isPreviewVisible, setIsPreviewVisible, onSave, playStory }) 
{
    return (
        <>
            <div className="absolute top-0 left-0 m-4 p-1 rounded-lg flex flex-col bg-shadow-grey gap-1 z-50">
                <FontAwesomeIcon icon={faFloppyDisk}  onClick={onSave}  className="cursor-pointer text-2xl py-2 px-1 text-white/70 hover:bg-charcoal-blue hover:text-white rounded" />
                <FontAwesomeIcon icon={faPlayCircle}  onClick={playStory}  className="cursor-pointer text-2xl py-2 px-1 text-white/70 hover:bg-charcoal-blue hover:text-white rounded" />
            </div>
            <button className="absolute top-0 right-0 m-4 p-1 cursor-pointer shadow-2xl hover:outline-tiger-orange outline-1 rounded-lg flex items-center bg-shadow-grey gap-2 z-50 hover:bg-charcoal-blue transition" onClick={() => setIsPreviewVisible(!isPreviewVisible)}>
                <FontAwesomeIcon icon={faGear} className="cursor-pointer text-xl py-2 px-1 text-white/70" />
                <h2 className="text-white/70 font-extralight font-outfit pr-2">Settings</h2>
            </button>
        </>
    );
}