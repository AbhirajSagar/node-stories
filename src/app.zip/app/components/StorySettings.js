import { faBrain, faClose, faFileAlt, faFlask, faGear, faPaintBrush } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";

import { AppearanceTabContent } from "./settingsTabContent/AppearanceTabContent";
import { GeneralTabContent } from "./settingsTabContent/GeneralTabContent";
import { AdvancedTabContent } from "./settingsTabContent/AdvancedTabContent";

export function Settings({ setIsPreviewVisible, appearance, setAppearance, name, description, setName, setDescription, timing, setTiming })
{
    const [tab, setTab] = useState(TABS.GENERAL);

    return (
        <div className="absolute top-0 right-0 p-3 w-82 rounded-l-2xl flex flex-col h-full bg-shadow-grey z-50">
            <Tabs currentTab={tab} name={name} description={description} setName={setName} setDescription={setDescription} setIsPreviewVisible={setIsPreviewVisible} setCurrentTab={setTab} tabs={Object.values(TABS)} appearance={appearance} setAppearance={setAppearance}  timing={timing} setTiming={setTiming}/>
        </div>
    );
}

function Tabs({ currentTab, setIsPreviewVisible, setCurrentTab, tabs, appearance, setAppearance, name, description, setName, setDescription, timing, setTiming})
{
    return (
        <>
            <div className="w-full flex mt-1 gap-1 flex-row">
            {tabs.map((tab, index) => (
                <button key={index} onClick={() => setCurrentTab(tab)} className={`text-white/80 rounded-md bg-deep-space-blue w-max flex items-center p-2 cursor-pointer ${currentTab === tab && 'flex-1' } hover:bg-shadow-grey-2 hover:outline-1 hover:outline-tiger-orange transition`}>
                    <FontAwesomeIcon icon={tab.icon} />
                    {currentTab === tab && <p className="font-extralight ml-2 text-sm">{tab.label}</p>}
                </button>
            ))}
            <button onClick={() => setIsPreviewVisible(false)} className="ml-auto text-white/80 rounded-md bg-deep-space-blue w-max flex items-center p-2 cursor-pointer hover:bg-shadow-grey-2 hover:outline-1 hover:outline-tiger-orange transition">
                <FontAwesomeIcon icon={faClose} />
            </button>
            </div>
            <div className="w-full mt-5">
                {currentTab.name === "General" && <GeneralTabContent name={name} description={description} setName={setName} setDescription={setDescription} />}
                {currentTab.name === "Appearance" && <AppearanceTabContent setAppearance={setAppearance} appearance={appearance}/>}
                {currentTab.name === "Advanced" && <AdvancedTabContent timing={timing} setTiming={setTiming} />}
            </div>
        </>
    );
}

const TABS =
{
    GENERAL: 
    {
        name: "General",
        label: "General Settings",
        icon: faGear,
    },
    APPEARANCE: 
    {
        name: "Appearance",
        label: "Appearance Settings",
        icon: faPaintBrush,
    },
    ADVANCED: 
    {
        name: "Advanced",
        label: "Advanced Settings",
        icon: faFlask,
    }
};