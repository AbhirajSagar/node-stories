import { faFileAlt, faFile, faVideo } from "@fortawesome/free-solid-svg-icons";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export function ContextMenu({ x, y, menuContent }) 
{
    return (
        <div className="min-w-42 w-max h-max p-2 absolute bg-shadow-grey/80 backdrop-blur-sm rounded-lg shadow-lg" style={{ top: y, left: x }}>
            {menuContent}
        </div>
    );
}

export function PaneContextMenu({ addNode }) 
{
    const options = 
    [
        {
            label: "Add Normal Node",
            icon: faFileAlt,
            onClick: () => addNode("normal", { x: 0, y: 0 })
        },
        {
            label: "Add Image Node",
            icon: faFile,
            onClick: () => addNode("image", { x: 0, y: 0 })
        },
        {
            label: "Add Video Node",
            icon: faVideo,
            onClick: () => addNode("video", { x: 0, y: 0 })
        }
    ];

    return Options(options);
}

export function EdgeContextMenu({ edge, deleteEdge }) 
{
    const options = [{ label: "Delete Edge", icon: faTrash, onClick: () => deleteEdge(edge.id) }];
    return Options(options);
}

function Options(options) 
{
    return options.map((o, i) => (
        <div key={i} className="w-full hover:cursor-pointer flex items-center hover:bg-deep-space-blue/50 p-2 rounded" onClick={() => o.onClick()}>
            <FontAwesomeIcon icon={o.icon} className="text-gray-300 mr-2" />
            <h2 className="text-gray-300 font-extralight font-outfit">{o.label}</h2>
        </div>
    ));
}