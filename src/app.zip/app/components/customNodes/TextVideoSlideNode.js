"use client";
import React, { useState, useCallback, useRef } from "react";
import { Handle, Position, useReactFlow, useUpdateNodeInternals } from "@xyflow/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUpload } from "@fortawesome/free-solid-svg-icons";

import Toolbar from "../NodeToolbar";
import Choices from "../Choices";
import { saveMediaToIndexedDB } from "@/app/utils/indexDb";

export default function VideoSlideNode({ id, selected, data })
{
  const updateNodeInternals = useUpdateNodeInternals();
  const { setNodes, setEdges } = useReactFlow();

  const videoUrlRef = useRef(null);
  const [, forceRender] = useState(0);
  const [choices, setChoices] = useState([""]);

  const addChoiceCallback = useCallback(() =>
  {
    setChoices((prev) =>
    {
      if(prev.length === 9) return prev;
      const next = [...prev, ""];
      updateNodeInternals(id);
      return next;
    });
  }, [id, updateNodeInternals]);

  const deleteNodeCallback = useCallback(() =>
  {
    setNodes((nds) => nds.filter((n) => n.id !== id));
    setEdges((eds) => eds.filter((e) => e.source !== id && e.target !== id));
  }, [id, setNodes, setEdges]);

  function setContent(e)
  {
    data.text = e.target.value;
  }

  function handleChoiceSelection(e, idx)
  {
    if(!data.choices) data.choices = [];
    if(!data.choices[idx]) data.choices[idx] = { content: "", connection: null };
    data.choices[idx].content = e.target.value;
  }

  function handleConnection(e, idx)
  {
    if(!data.choices) data.choices = [];
    if(!data.choices[idx]) data.choices[idx] = { content: "", connection: null };
    data.choices[idx].connection = e.target;
  }

  return (
    <div className={`bg-shadow-grey p-2 min-h-32 h-max min-w-48 font-outfit rounded-lg shadow-xl text-white border-tiger-orange ${selected ? "border" : ""}`}>
      <Handle type="target" position={Position.Left} id="target" />

      <div className="nodrag flex flex-col mt-12">
        <VideoUpload
          id={id}
          data={data}
          videoUrlRef={videoUrlRef}
          forceRender={forceRender}
        />

        <textarea
          onChange={setContent}
          placeholder="Enter text here.."
          className="bg-deep-space-blue rounded focus:outline-tiger-orange focus:outline-1 p-1 text-xs font-extralight w-full"
        />

        <Choices
          choices={choices}
          setChoice={handleChoiceSelection}
          handleConnection={handleConnection}
        />
      </div>

      <Toolbar addChoice={addChoiceCallback} deleteNode={deleteNodeCallback} />
    </div>
  );
}

function VideoUpload({ id, data, videoUrlRef, forceRender })
{
  async function handleVideoUpload(e)
  {
    const file = e.target.files[0];
    if(!file) return;

    if(videoUrlRef.current)
    {
      URL.revokeObjectURL(videoUrlRef.current);
    }

    videoUrlRef.current = URL.createObjectURL(file);
    forceRender(v => v + 1);

    await saveMediaToIndexedDB(id, file);
    data.key = id;
  }

  return (
    <div className="flex relative items-center bg-deep-space-blue rounded mb-1.5 h-42 justify-center">
      <div className="bg-deep-space-blue rounded-lg flex items-center justify-center w-full h-full">
        {
          videoUrlRef.current
          ? (
            <video
              src={videoUrlRef.current}
              controls
              className="h-42 w-full object-cover rounded-lg"
            />
          )
          : (
            <div className="flex justify-center cursor-pointer items-center flex-col">
              <FontAwesomeIcon icon={faUpload} className="text-4xl mb-2" />
              <span className="text-gray-300 text-semibold">Upload Video</span>
            </div>
          )
        }
      </div>

      <input
        type="file"
        accept="video/*"
        onChange={handleVideoUpload}
        className="absolute cursor-pointer top-0 left-0 h-full w-full opacity-0"
      />
    </div>
  );
}