import Accordion from "../Accordion";

export function GeneralTabContent({ name, description, setName, setDescription })
{
    return (
        <div className="text-white/80">
            <Accordion title="Name & Description" defaultOpen={true} className="mb-4">
              <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full mt-1 p-2 rounded bg-deep-space-blue text-white/80 outline-none focus:ring-1 focus:ring-tiger-orange transition" placeholder="Story Name" />
              <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full flex-1 mt-1 p-2 rounded bg-deep-space-blue text-white/80 outline-none focus:ring-1 focus:ring-tiger-orange transition" placeholder="Enter story's description..." />
            </Accordion>
        </div>
    );
}