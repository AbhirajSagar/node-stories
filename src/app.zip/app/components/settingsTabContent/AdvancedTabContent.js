import Accordion from "../Accordion";

export function AdvancedTabContent({timing, setTiming})
{
    return (
        <div className="text-white/80">
            <Accordion title="Delay In Choices Reveal" defaultOpen={true} className="mb-4">
                <input type="number" value={timing?.delay || 0} onChange={e => setTiming({ ...timing, delay: e.target.value })}  step={0.5} min={0} max={10} className="w-full bg-deep-space-blue p-2 rounded"/>
            </Accordion>
        </div>
    );
}