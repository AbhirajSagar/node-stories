import { useState } from "react";
import { faChevronCircleDown } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Accordion from "../Accordion";

// Custom scrollbar styles
const scrollbarStyles = `
  ::-webkit-scrollbar {
    width: 8px;
  }
  
  ::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 4px;
  }
  
  ::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.15);
    border-radius: 4px;
    border: 2px solid transparent;
    background-clip: content-box;
  }
  
  ::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.3);
    background-clip: content-box;
  }
`;

// Inject styles on component mount
if (typeof document !== "undefined") {
  const style = document.createElement("style");
  style.textContent = scrollbarStyles;
  document.head.appendChild(style);
}

// Gradient presets with descriptive names
const GRADIENT_PRESETS = [
  { name: "Midnight", from: "#0f172a", to: "#020617" },
  { name: "Lavender Dream", from: "#a18cd1", to: "#fbc2eb" },
  { name: "Golden Sunrise", from: "#f6d365", to: "#fda085" },
  { name: "Mint Blue", from: "#84fab0", to: "#8fd3f4" },
  { name: "Peach Purple", from: "#fccb90", to: "#d57eeb" },
  { name: "Pink Lemonade", from: "#fa709a", to: "#fee140" },
  { name: "Sky Ocean", from: "#89f7fe", to: "#66a6ff" },
];

// Reusable color picker component
function ColorPickerPair({ label, fromValue, toValue, onFromChange, onToChange }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <label className="text-sm font-medium text-white/70 w-12">From</label>
        <div className="flex-1 flex items-center gap-2">
          <input
            type="color"
            value={fromValue}
            onChange={onFromChange}
            className="h-10 w-16 rounded border border-white/10 cursor-pointer hover:border-white/20 transition-colors"
          />
          <span className="text-xs text-white/50 font-mono">{fromValue}</span>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <label className="text-sm font-medium text-white/70 w-12">To</label>
        <div className="flex-1 flex items-center gap-2">
          <input
            type="color"
            value={toValue}
            onChange={onToChange}
            className="h-10 w-16 rounded border border-white/10 cursor-pointer hover:border-white/20 transition-colors"
          />
          <span className="text-xs text-white/50 font-mono">{toValue}</span>
        </div>
      </div>
    </div>
  );
}

// Reusable gradient preview component
function GradientPreview({ from, to, label, height = "h-12" }) {
  return (
    <div className={`w-full ${height} rounded-lg overflow-hidden border border-white/10 shadow-md`}
      style={{
        background: `linear-gradient(135deg, ${from}, ${to})`,
      }}>
      <div className="w-full h-full flex items-center justify-center">
        <p className="text-white/80 text-sm font-medium drop-shadow">{label}</p>
      </div>
    </div>
  );
}

// Reusable accordion component


// Preset gradient selector
function PresetSelector({ presets, onSelect }) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {presets.map((preset) => (
        <button
          key={preset.name}
          onClick={() => onSelect(preset)}
          className="relative group rounded-lg overflow-hidden border-2 border-white/10 hover:border-white/30 transition-all hover:shadow-lg"
          title={preset.name}
        >
          <div
            className="h-12 w-full"
            style={{
              background: `linear-gradient(135deg, ${preset.from}, ${preset.to})`,
            }}
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
            <p className="text-white/90 text-xs font-semibold text-center px-2">{preset.name}</p>
          </div>
        </button>
      ))}
    </div>
  );
}

// Main component
export function AppearanceTabContent({ setAppearance, appearance }) {
  const bgFrom = appearance?.bg_from || "#0f172a";
  const bgTo = appearance?.bg_to || "#020617";
  const optionFrom = appearance?.option_from || "#ED8836";
  const optionTo = appearance?.option_to || "#FB923C";
  const hoveredFrom = appearance?.hovered_option_from || "#ED8836";
  const hoveredTo = appearance?.hovered_option_to || "#FB923C";

  const handleBackgroundPreset = (preset) => {
    setAppearance({ ...appearance, bg_from: preset.from, bg_to: preset.to });
  };

  const handleOptionPreset = (preset) => {
    setAppearance({ ...appearance, option_from: preset.from, option_to: preset.to });
  };

  const handleHoveredPreset = (preset) => {
    setAppearance({ ...appearance, hovered_option_from: preset.from, hovered_option_to: preset.to });
  };

  return (
    <div className="h-screen overflow-y-auto text-white/80">
      {/* Content */}
      <div className="max-w-2xl mx-auto space-y-4 pr-1">
        {/* Background Gradient Section */}
        <Accordion title="Background Gradient" defaultOpen={true}>
          <div className="space-y-4">
            {/* Large preview */}
            <GradientPreview from={bgFrom} to={bgTo} label="Background Preview" height="h-32" />

            {/* Preset selector */}
            <div>
              <p className="text-xs font-semibold text-white/60 uppercase tracking-wide mb-3">
                Quick Presets
              </p>
              <PresetSelector presets={GRADIENT_PRESETS} onSelect={handleBackgroundPreset} />
            </div>

            {/* Custom colors */}
            <div>
              <p className="text-xs font-semibold text-white/60 uppercase tracking-wide mb-3">
                Custom Colors
              </p>
              <ColorPickerPair
                label="Background"
                fromValue={bgFrom}
                toValue={bgTo}
                onFromChange={(e) => setAppearance({ ...appearance, bg_from: e.target.value })}
                onToChange={(e) => setAppearance({ ...appearance, bg_to: e.target.value })}
              />
            </div>
          </div>
        </Accordion>

        {/* Choice Button Gradient Section */}
        <Accordion title="Choice Button Gradient">
          <div className="space-y-4">
            {/* Preview of both states */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-white/60 uppercase tracking-wide">Preview</p>
              <GradientPreview from={optionFrom} to={optionTo} label="Default State" />
            </div>

            {/* Preset selector */}
            <div>
              <p className="text-xs font-semibold text-white/60 uppercase tracking-wide mb-3">
                Quick Presets
              </p>
              <PresetSelector presets={GRADIENT_PRESETS} onSelect={handleOptionPreset} />
            </div>

            {/* Custom colors */}
            <div>
              <p className="text-xs font-semibold text-white/60 uppercase tracking-wide mb-3">
                Custom Colors
              </p>
              <ColorPickerPair
                label="Default"
                fromValue={optionFrom}
                toValue={optionTo}
                onFromChange={(e) => setAppearance({ ...appearance, option_from: e.target.value })}
                onToChange={(e) => setAppearance({ ...appearance, option_to: e.target.value })}
              />
            </div>
          </div>
        </Accordion>

        {/* Hover State Gradient Section */}
        <Accordion title="Hover Effect Gradient" className='mb-34'>
          <div className="space-y-4">
            {/* Preview */}
            <GradientPreview from={hoveredFrom} to={hoveredTo} label="Hover Preview" height="h-16" />

            {/* Preset selector */}
            <div>
              <p className="text-xs font-semibold text-white/60 uppercase tracking-wide mb-3">
                Quick Presets
              </p>
              <PresetSelector presets={GRADIENT_PRESETS} onSelect={handleHoveredPreset} />
            </div>

            {/* Custom colors */}
            <div>
              <p className="text-xs font-semibold text-white/60 uppercase tracking-wide mb-3">
                Custom Colors
              </p>
              <ColorPickerPair
                label="Hover"
                fromValue={hoveredFrom}
                toValue={hoveredTo}
                onFromChange={(e) => setAppearance({ ...appearance, hovered_option_from: e.target.value })}
                onToChange={(e) => setAppearance({ ...appearance, hovered_option_to: e.target.value })}
              />
            </div>
          </div>
        </Accordion>

        {/* Footer spacing */}
        <div className="pt-4" />
      </div>
    </div>
  );
}