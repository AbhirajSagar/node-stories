'use client';
import { useEffect, useState } from "react";
import extractFlowData from "@/app/utils/flowExtractor";
import { getMediaFromIndexedDB } from "../utils/indexDb";

export default function Page()
{
    const [slidesArr, setSlidesArr] = useState([]);
    const [currSlide, setCurrSlide] = useState(null);
    const [appearance, setAppearance] = useState();
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [timing, setTiming] = useState({});


    useEffect(() => { loadSlides(); }, []);

    function loadSlides()
    {
        const data = sessionStorage.getItem('storyData');
        if(!data) return;

        const json = JSON.parse(data);
        console.log(json);
        const { slides, appearance, name, description, timing } = extractFlowData(json, json.version);

        setSlidesArr(slides);
        setAppearance(appearance);
        setDescription(description);
        setTiming(timing);
        setName(name);
        setCurrSlide(slides[0]);
    }

    function setCurrSlideById(id)
    {
        const slide = slidesArr.find(s => s.id === id);
        if(slide) setCurrSlide(slide);
    }

    if(!currSlide) return null;

    return (
        <div className="w-screen h-screen bg-black flex flex-col overflow-hidden">
            {currSlide.type === 'image'  && <ImageSlide  slide={currSlide} appearance={appearance} setCurrSlideById={setCurrSlideById} />}
            {currSlide.type === 'video'  && <VideoSlide  slide={currSlide} appearance={appearance} setCurrSlideById={setCurrSlideById} />}
            {currSlide.type === 'normal' && <NormalSlide slide={currSlide} appearance={appearance} setCurrSlideById={setCurrSlideById} />}
        </div>
    );
}

function ImageSlide({ slide, appearance, setCurrSlideById })
{
    const [imageSrc, setImageSrc] = useState(null);

    useEffect(() =>
    {
        let url;

        async function loadImage()
        {
            try
            {
                const media = await getMediaFromIndexedDB(slide.data.key);
                url = URL.createObjectURL(media);
                setImageSrc(url);
            }
            catch
            {
                setImageSrc(null);
            }
        }

        loadImage();

        return () => url && URL.revokeObjectURL(url);
    }, [slide]);

    return (
        <div className="w-full h-full relative">
            {imageSrc && <img src={imageSrc} className="w-full h-full object-cover"/>}
            <Interaction currSlide={slide} setCurrSlideById={setCurrSlideById} appearance={appearance}/>
        </div>
    );
}

function VideoSlide({ slide, appearance, setCurrSlideById })
{
    const [videoSrc, setVideoSrc] = useState(null);

    useEffect(() =>
    {
        let url;
        async function loadVideo()
        {
            try
            {
                const media = await getMediaFromIndexedDB(slide.data.key);
                url = URL.createObjectURL(media);
                setVideoSrc(url);
            }
            catch
            {
                setVideoSrc(null);
            }
        }

        loadVideo();
        return () => url && URL.revokeObjectURL(url);
    }, [slide]);

    return (
        <div className="w-full h-full relative">
            {videoSrc && <video src={videoSrc} className="w-full h-full object-cover" autoPlay loop/>}
            <Interaction currSlide={slide} setCurrSlideById={setCurrSlideById} appearance={appearance} />
        </div>
    );
}

function NormalSlide({ slide, appearance, setCurrSlideById })
{
    return (
        <div className="w-full h-full relative flex justify-center items-center" style={{ background: `linear-gradient(to bottom right, ${appearance?.bg_from || '#0f172a'}, ${appearance?.bg_to || '#020617'})` }}>
            <div className="max-w-3xl px-6 text-center">
                <p className="text-white text-lg sm:text-xl md:text-2xl leading-relaxed">
                    {slide.data.text || "No Content"}
                </p>
            </div>
            <Interaction currSlide={slide} setCurrSlideById={setCurrSlideById} appearance={appearance} />
        </div>
    );
}

function Interaction({ currSlide, setCurrSlideById, appearance })
{
    if (!currSlide.data.choices?.length) return null;

    const styles = 
    {
        notHovered: { background: `linear-gradient(to bottom right, ${appearance?.option_from || '#FFFFFF'}, ${appearance?.option_to || '#FFFFFF'})` },
        hovered:    { background: `linear-gradient(to bottom right, ${appearance?.hovered_option_from || '#ED8836'}, ${appearance?.hovered_option_to || '#FB923C'})` }
    };

    const [hovered, setIsHovered] = useState({});

    return (
        <div className="absolute bottom-0 w-full p-4 sm:p-6">
            {currSlide.type !== 'normal' && currSlide.data.text && 
                <h2 className="w-full text-white shadow-2xl text-center flex items-center justify-center my-2 h-12 text-xl">
                    {currSlide.data.text}
                </h2>
            }
            <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
                {currSlide.data.choices.map((choice, index) => 
                (
                    <button
                        key={index}
                        onClick={() => setCurrSlideById(choice.connection)}
                        onPointerEnter={() => setIsHovered({...hovered, [index]: true})}
                        onPointerLeave={() => setIsHovered({...hovered, [index]: false})}
                        style={hovered[index] ? styles.hovered : styles.notHovered}
                        className="px-4 py-2 rounded-xl shadow-md text-sm sm:text-base font-medium cursor-pointer hover:text-white hover:scale-105 transition"
                    >
                        {choice.content}
                    </button>
                ))}
            </div>
        </div>
    );
}
